const express = require('express');
const app  = express();
const router = express.Router();
const bodyParser = require('body-parser');
const expressValidator = require('express-validator');

app.use(express.json());
app.use(bodyParser.json());

const getAssociate = require('./router/associate');
const getProduct = require('./router/product');
const getAccount = require('./router/account');
const getInventory = require('./router/inventory');
const getProject = require('./router/project');


app.use(getAssociate);
app.use(getProduct);
app.use(getAccount);
app.use(getInventory);
app.use(getProject);

app.listen (3000);