const service = require('../services/accountService');
const jwtService = require('../helper/jwtLib');

module.exports.getAccountProdDataById = function getAccountProdDataById(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getAccountProdDataById(req,res)        
    });

};


module.exports.getAllAccountProdData = function getAllAccountProdData(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getAllAccountProdData(req,res)        
    });

};

module.exports.getAcctProductByName = function getAcctProductByName(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getAcctProductByName(req,res)        
    });

};


module.exports.updateAccount = function updateAccount(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.updateAccount(req,res)        
    });
};

module.exports.getAccountById = function getAccountById(req,res,next) {
        jwtService.validateToken(req,res,async function()  {
            await service.getAccountById(req,res)        
        });

};

module.exports.getAllAccount = function getAllAccount(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getAllAccount(req,res)        
    });

};

module.exports.getAccountByNameCity = function getAccountByNameCity(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getAccountByNameCity(req,res)        
    });

};

module.exports.addacctdtls = function addacctdtls(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addacctdtls(req,res)
        
    });

};

module.exports.addemplactdtls = function addemplactdtls(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addemplactdtls(req,res)
        
    });

};
