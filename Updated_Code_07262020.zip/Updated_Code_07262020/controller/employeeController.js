const service = require('../services/employeeService');
const jwtService = require('../helper/jwtLib');

module.exports.getEmployee = function getEmployee(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getEmployee(req,res)        
    });

};

module.exports.updateEmployee = function updateEmployee(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.updateEmployee(req,res)
        
    });

};

module.exports.addAssociate = function addAssociate(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addAssociate(req,res)
        
    });

};

module.exports.addempSkills = function addempSkills(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addempSkills(req,res)
        
    });

};

module.exports.addSkilldtls = function addSkilldtls(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addSkilldtls(req,res)
        
    });

};


module.exports.updateEmployeeSkills = function updateEmployeeSkills(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.updateEmployeeSkills(req,res)        
    });

};

module.exports.getEmpSkillsData = function getEmpSkillsData(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getEmpSkillsData(req,res)        
    });

};