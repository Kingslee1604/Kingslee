const service = require('../services/inventoryService');
const jwtService = require('../helper/jwtLib');

module.exports.getInventoryByAccountId = function getInventorybyAccountId(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getInventoryByAccountId(req,res)        
    });

};



module.exports.getInventory = function getInventory(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getInventory(req,res)        
    });

};


module.exports.updateInventory = function updateInventory(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.updateInventory(req,res)        
    });

};

module.exports.addacctinvtdtls = function addacctinvtdtls(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addacctinvtdtls(req,res)
        
    });
};