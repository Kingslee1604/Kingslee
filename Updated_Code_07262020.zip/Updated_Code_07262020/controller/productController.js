const service = require('../services/productService');
const jwtService = require('../helper/jwtLib');

module.exports.getProduct = function getProduct(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getProduct(req,res)        
    });

};

module.exports.getProductDesc = function getProductDesc(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getProductDesc(req,res)        
    });

};

module.exports.getProdOnVendor = function getProdOnVendor(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getProdOnVendor(req,res)        
    });

};


module.exports.updateVendor = function updateVendor(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.updateVendor(req,res)        
    });

};

module.exports.addpdpddtls = function addpdpddtls(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addpdpddtls(req,res)
        
    });

};

module.exports.addacctpdpddtls = function addacctpdpddtls(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addacctpdpddtls(req,res)
        
    });

};
module.exports.deletepdpddtls = function deletepdpddtls(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.deletepdpddtls(req,res)
        
    });

};

module.exports.addprojdtls = function addprojdtls(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addprojdtls(req,res)
        
    });
};