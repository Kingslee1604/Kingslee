const service = require('../services/projectService');
const jwtService = require('../helper/jwtLib');

module.exports.getProject = function getProject(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.getProject(req,res)        
    });

};
module.exports.addprojdtlstest = function addprojdtlstest(req,res,next) {
    jwtService.validateToken(req,res,async function()  {
        await service.addprojdtlstest(req,res)
        
    });
};
