const dotenv = require('dotenv');
dotenv.config();
module.exports = {   
  
  serverName: process.env.MSSQL_SERVER,
  database: process.env.MSSQL_DATABASE,
  environment: process.env.NODE_ENV,
  jwtSecret: process.env.JWT_SECRET 
};