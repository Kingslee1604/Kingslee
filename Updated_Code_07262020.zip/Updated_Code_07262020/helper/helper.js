const sql = require('mssql/msnodesqlv8');
const { serverName,database } = require('../helper/config');

const poolPromise = new sql.ConnectionPool({
  database: database,
  server: serverName,
  driver: 'msnodesqlv8',
  options: {
    trustedConnection: true
  }
})
  .connect()
  .then(pool => {
    console.log('Connected to MSSQL')
    return pool
  })
  .catch(err => console.log('Database Connection Failed! Bad Config: ', err))

module.exports = {
  sql, poolPromise
}

