const jwt = require('jsonwebtoken');
const { jwtSecret } =  require('../helper/config');
/* module.exports.authenticateToken = function (req, res, next) {
    // Gather the jwt access token from the request header
    try {
    if(req.header && req.headers.authorization){
    const token = req.headers['authorization']    
    if (token == null) return res.sendStatus(401) // if there isn't any token
  
    jwt.verify(token, process.env.JWT_SECRET,
      {
        algorithms: 'HS256',
        ignoreNotBefore: true
      }, (err, user) => {
      console.log(err)
      if (err) return res.sendStatus(403)
      req.user = user
      next() // pass the execution off to whatever request the client intended
    })
  } else {
    res.sendStatus= 401;
    return res.send('JWT required');
  }
}catch(error){
  return error;
}
  } */
  

  module.exports = {
    validateToken: (req, res, next) => {
      const authorizationHeaader = req.headers.authorization;
      let result;
      if (authorizationHeaader) {
        const token = req.headers.authorization; // Bearer <token>
        const options = {
          expiresIn: '2d'
        
        };
        try {
          // verify makes sure that the token hasn't expired and has been issued by us
          result = jwt.verify(token, jwtSecret, options);
  
          // Let's pass back the decoded token to the request object
          req.decoded = result;
          // We call next to pass execution to the subsequent middleware
          next();
        } catch (err) {
          // Throw an error just in case anything goes wrong with verification
          res.status(401).send(err);
          throw new Error(err);
          
        }
      } else {
        result = { 
          error: `Authentication error. Token required.`,
          status: 401
        };
        res.status(401).send(result);
      }
    }
  };