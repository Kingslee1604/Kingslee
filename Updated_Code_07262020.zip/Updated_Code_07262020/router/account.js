const express = require('express');
const router = express.Router();
const accountController = require('../controller/accountController');
const { check, oneOf, validationResult } = require('express-validator');


router.get('/getAccountProdDataById', [
  check('accountId').exists()
  .withMessage('Account id is required')
], async (req, res) => {    
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() })
  }    
  accountController.getAccountProdDataById(req,res);
})



router.get('/getAllAccountProdData', async (req, res) => {        
  accountController.getAllAccountProdData(req,res);
})



router.get('/getAcctProductByName', async (req, res) => {        
  accountController.getAcctProductByName(req,res);
})


router.put('/updateAccount', async (req, res) => {        
    accountController.updateAccount(req,res);
  })
  

  
router.get('/getAccountById', [
  check('accountId').exists()
  .withMessage('Account id is required')
], async (req, res) => {    
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() })
  }    
  accountController.getAccountById(req,res);
})


router.get('/getAllAccount', async (req, res) => {        
  accountController.getAllAccount(req,res);
})



router.get('/getAccountByNameCity',[oneOf( // <-- one of the following must exist
  [
    check('accountName').exists().isString(),
    check('accountState').exists().isString(),
    check('accountCity').exists().isString(),
  ])],
  async (req, res) => {
    const errors = validationResult(req)
if (!errors.isEmpty()) {
  return res.status(422).json({ errors: '[Either Account Name or State or City should be passed]' })
}       
  accountController.getAccountByNameCity(req,res);
})

router.post('/addacctdtls', [
  check('accountid').isNumeric()
  .withMessage('Account ID is Required and Should be Numeric'),
  check('accountname').isAlpha()
  .withMessage('Account Name is Required'),
  ],
  async (req, res) => {
    const errors = validationResult(req)
if (!errors.isEmpty()) {
  return res.status(422).json({ errors: errors.array()  })
}
  accountController.addacctdtls(req, res);
});

router.post('/addemplactdtls', [
  check('empId').isNumeric()
  .withMessage('EmpID is Required and Should be Numeric'),
/*  check('accountId').isNumeric()
  .withMessage('accountId is Required and Should be Numeric'),*/
  ],
  async (req, res) => {
    const errors = validationResult(req)
if (!errors.isEmpty()) {
  return res.status(422).json({ errors: errors.array()  })
}
  accountController.addemplactdtls(req, res);
});

module.exports= router;
