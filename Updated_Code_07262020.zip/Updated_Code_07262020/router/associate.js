const express = require('express');
const router = express.Router();
const employeeController = require('../controller/employeeController');
const { check, oneOf, validationResult } = require('express-validator');


router.get('/getEmp/:id' ,  [
  check('id').isNumeric()
  .withMessage('Should be Numeric')
], async (req, res) => {   
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() })
  }
    employeeController.getEmployee(req,res);
  });

  router.get('/getEmpSkillsData',[oneOf( // <-- one of the following must exist
    [
      check('employeeName').exists().isString(),
      check('skillName').exists().isString(),
    ])],
    async (req, res) => {
      const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: '[Either SkillName or Employee Name should be present]' })
  }
    employeeController.getEmpSkillsData(req, res);
  });
  
  router.put('/updateEmp/:id',  (req, res) => {
    
    employeeController.updateEmployee(req, res);
  });
  
  router.put('/updateEmpSkills/:id', (req, res) => {
    employeeController.updateEmployeeSkills(req, res);
  });

  router.post('/addAssociate', [
    check('empId').isNumeric()
    .withMessage('EmpID is Required and Should be Numeric'),        
    check('empName').isAlpha()
    .withMessage('Emp Name is required')
  ],
    async (req, res) => {
      const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array()  })
  }
    employeeController.addAssociate(req, res);
  });

  router.post('/addempSkills', [
    check('empId').isNumeric()
    .withMessage('EmpID is Required and Should be Numeric'),        
    check('skillId').isNumeric()
    .withMessage('SkillID is Required and Should be Numeric')
    ],
    async (req, res) => {
      const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array()  })
  }
    employeeController.addempSkills(req, res);
  });

  router.post('/addSkilldtls', [
    check('skillId').isNumeric()
    .withMessage('SkillID is Required and Should be Numeric'),
    check('skillName').isAlphanumeric()
    .withMessage('skillName is Required'),
    check('skillType').isAlphanumeric()
    .withMessage('skillType is Required'),
    check('skillWeight').isNumeric()
    .withMessage('skillWeight is Required'),
    ],
    async (req, res) => {
      const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array()  })
  }
    employeeController.addSkilldtls(req, res);
  });
 

  module.exports =   router;
  