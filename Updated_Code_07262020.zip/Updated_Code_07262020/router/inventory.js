const express = require('express');
const router = express.Router();
const inventoryController = require('../controller/inventoryController');
const { check, oneOf, validationResult } = require('express-validator');

router.get('/getInventoryByAccountId' ,  [
    check('accountId').exists()
    .withMessage('Should be Numeric')
  ], async (req, res) => {   
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() })
    }
      inventoryController.getInventoryByAccountId(req,res);
    });

    router.get('/getInventory' ,[oneOf( // <-- one of the following must exist
        [
          check('inventoryName').exists().isString(),
          check('inventoryDesc').exists().isString(),
          check('mapping').exists().isString(),
          check('funcCategory').exists().isString(),
          check('destination').exists().isString(),
          check('frequency').exists().isString()
        ])],
        async (req, res) => {
          const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(422).json({ errors: '[Either InventoryName/Inventorydesc/mapping/FunctionCategory/Destination/Frequency] should be passed' })
      }       
          inventoryController.getInventory(req,res);
        });


        router.put('/updateInventory' , // <-- one of the following must exist
            [
              check('inventoryName').exists().withMessage('Inventory Name should be present'),
              check('inventoryDesc').exists().withMessage('Inventory Desc should be present'),
              check('mapping').exists().withMessage('Mapping should be present'),
              check('funcCategory').exists().withMessage('Functional Category should be present'),
              check('destination').exists().withMessage('Destination should be present'),
              check('frequency').exists().withMessage('Frequency  should be present'),
              check('accountName').exists().withMessage('Account Name  should be present'),
              check('updateUser').exists().withMessage('UpdateUser  should be present'),
            ],
            async (req, res) => {
              const errors = validationResult(req)
          if (!errors.isEmpty()) {
            return res.status(422).json({ errors: errors.array()})
          }       
              inventoryController.updateInventory(req,res);
            });
    
            router.post('/addacctinvtdtls', [
              check('accountid').isNumeric()
              .withMessage('Account ID is Required and Should be Numeric'),
              check('invtname').isAlpha()
              .withMessage('Inventary Name is Required'),
              check('invtdesc').isAlpha()
              .withMessage('Inventary Description is Required'),
              check('mapping').isAlpha()
              .withMessage('Mapping is Required'),
          
            ],
              async (req, res) => {
                const errors = validationResult(req)
            if (!errors.isEmpty()) {
              return res.status(422).json({ errors: errors.array()  })
            }
              inventoryController.addacctinvtdtls(req, res);
            });
    module.exports =   router;