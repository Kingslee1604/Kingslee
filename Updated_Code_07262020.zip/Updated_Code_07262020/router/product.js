const express = require('express');
const router = express.Router();
const productController = require('../controller/productController');
const { check, oneOf, validationResult } = require('express-validator');


router.get('/getProduct', (req, res) => {
    productController.getProduct(req, res);
  });


  
router.get('/getProductDesc', (req, res) => {
    productController.getProductDesc(req, res);
  });


  router.get('/getProdOnVendor', (req, res) => {
    productController.getProdOnVendor(req, res);
  });


  router.get('/updateVendor', (req, res) => {
    productController.updateVendor(req, res);
  });

  router.post('/addpdpddtls', [
    check('productid').isNumeric()
    .withMessage('Product ID is Required and Should be Numeric'),
    check('productname').isAlpha()
    .withMessage('Product Name is Required'),
    check('isTrizetto').isAlpha()
    .withMessage('Trizetto Flag is Required'),
    ],
    async (req, res) => {
      const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array()  })
  }
    productController.addpdpddtls(req, res);
  });

  router.post('/addprojdtls', [
    check('accountid').isNumeric()
    .withMessage('Account ID is Required and Should be Numeric'),
    check('projectid').isNumeric()
    .withMessage('Project ID is Required'),
  ],
    async (req, res) => {
      const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array()  })
  }
  productController.addprojdtls(req, res);
  });

  router.post('/addacctpdpddtls', [
    check('accountid').isNumeric()
    .withMessage('Account ID is Required and Should be Numeric'),
    check('productid').isNumeric()
    .withMessage('Prodcut ID is Required'),
  ],
    async (req, res) => {
      const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array()  })
  }
    productController.addacctpdpddtls(req, res);
  });

  router.delete('/deletepdpddtls', [
    check('productid').isNumeric()
    .withMessage('Product ID is Required and Should be Numeric'),
    ],
    async (req, res) => {
      const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array()  })
  }
    productController.deletepdpddtls(req, res);
    console.log("deletepdpddtls")
  });


module.exports = router;