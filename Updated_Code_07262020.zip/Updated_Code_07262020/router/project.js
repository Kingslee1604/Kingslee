const express = require('express');
const router = express.Router();
const projectController = require('../controller/projectController');
const { check, oneOf, validationResult } = require('express-validator');

router.get('/getProject', (req, res) => {
    projectController.getProject(req, res);
  });


router.post('/addprojdtlstest', [
    check('accountid').isNumeric()
    .withMessage('Account ID is Required and Should be Numeric'),
    check('projectid').isNumeric()
    .withMessage('Project ID is Required'),
  ],
    async (req, res) => {
      const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array()  })
  }
  projectController.addprojdtlstest(req, res);
  });
