const helper = require('../helper/helper');
const _ = require('lodash');

 async function getAccountProdDataById(req,res) {            
    try {       
      const pool = await helper.poolPromise;       
            //simple query
            const accountId = req.body.accountId
           let result  =  await pool.request().query(`select * from ctst_cust_acct_product_dtls where account_id =${accountId}`);
           res.json(result.recordset);
          } catch (err) {
         res.status(500);          
         res.send(err.message)
          }      
      }


      async function getAllAccountProdData(req,res) {            
        try {       
          const pool = await helper.poolPromise;                       //simple query
              
               let result  =  await pool.request().query(`select * from ctst_cust_acct_product_dtls`);
               res.json(result.recordset);
              } catch (err) {
             res.status(500);          
             res.send(err.message)
              }      
          }
    

    async function getAcctProductByName(req,res) {    
        
        try {       
    
          const getProdAcctData = {
            productName: req.body.productName?"'"+req.body.productName+"'":"''",
            accountName:  req.body.accountName?"'"+req.body.accountName+"'":"''",
            isTrizetto : req.body.isTrizetto?"'"+req.body.isTrizetto+"'":"'Y','N'"
          };
    
          
          const pool = await helper.poolPromise;   
                //simple query
               let result  =  await pool.request().query(`select product.product_id,product_name,is_Trizetto, vendor, product_desc, account_name,account_id,term_date,effective_date,version from ctst_cust_product_dtls product join ctst_cust_acct_product_dtls acct on product.product_id=acct.product_id where `+
               `(product.product_name=${getProdAcctData.productName} or acct.account_name=${getProdAcctData.accountName}) and is_Trizetto in (${getProdAcctData.isTrizetto})`)               
               res.status(200)
               res.json(result.recordset);
              } catch (err) {
                res.status(500);          
                res.send(err.message)
               }   
         
          }

      
          async function updateAccount(req,res) {            
            try {       
              const pool = await helper.poolPromise;       
                    //simple query
                    const accountName = req.body.accountName;
                    const productName = req.body.prodName;
                    const effDate = req.body.effDate;
                    const termDate = req.body.termDate;
                    const version = req.body.version;  
                    const accountId=req.body.accountId;                      
                   let result  =  await pool.request().query(`update ctst_cust_acct_product_dtls  set  effective_date='${effDate}', term_date='${termDate}', version='${version}', update_date=getdate(),`+
                                                            `product_id=(select product_id from ctst_cust_product_dtls where product_name='${productName}') where account_id=${accountId}`)
                   res.status(200)
                   res.send(result.rowsAffected +' account updated ')
                  } catch (err) {
                 res.status(500);          
                 res.send(err.message)
                  }      
              }     


              async function getAccountById(req,res) {            
                try {       
                  const pool = await helper.poolPromise;      //simple query                         
                        const accountId=req.body.accountId;                      
                       let result  =  await pool.request().query(`select account_id, account_name, primary_location_city, primary_location_state,cluster_id from ctst_cust_acct_dtls where account_id = ${accountId}`)
                        res.status(200)
                        res.json(result.recordset);
                      } catch (err) {
                     res.status(500);          
                     res.send(err.message)
                      }      
                  }     


                  async function getAllAccount(req,res) {            
                    try {       
                      const pool = await helper.poolPromise;      //simple query                                                   
                           let result  =  await pool.request().query(`select account_id, account_name, primary_location_city, primary_location_state,cluster_id from ctst_cust_acct_dtls`)
                            res.status(200)
                            res.json(result.recordset);
                          } catch (err) {
                         res.status(500);          
                         res.send(err.message)
                          }      
                      }  
                      
                      async function getAccountByNameCity(req,res) {            

                        const getAccData = {
                          accountCity: req.body.accountCity?"'%"+req.body.accountCity+"%'":"''",
                          accountName:  req.body.accountName?"'%"+req.body.accountName+"%'":"''",
                          accountState : req.body.accountState?"'%"+req.body.accountState+"%'":"''"
                        };
                        try {       
                          const pool = await helper.poolPromise;      //simple query                         
                                const accountId=req.body.accountId;                      
                               let result  =  await pool.request().query(`select account_id, account_name, primary_location_city, primary_location_state,cluster_id from ctst_cust_acct_dtls where account_name like ${getAccData.accountName} or primary_location_city like ${getAccData.accountCity}  or primary_location_state like ${getAccData.accountState}`)
                                res.status(200)
                                res.json(result.recordset);
                              } catch (err) {
                             res.status(500);          
                             res.send(err.message)
                              }      
                          }   
                          
                          
                          async function getAllAccount(req,res) {            
                            try {       
                              const pool = await helper.poolPromise;      //simple query                                                   
                                   let result  =  await pool.request().query(`select account_id, account_name, primary_location_city, primary_location_state,cluster_id from ctst_cust_acct_dtls`)
                                    res.status(200)
                                    res.json(result.recordset);
                                  } catch (err) {
                                 res.status(500);          
                                 res.send(err.message)
                                  }      
                              }  
                              
                              async function getAllEmpAccountDetails(req,res) {            
        
                                const getAccData = {
                                  accountName: req.body.accountName?"'%"+req.body.accountName+"%'":"''",
                                  empName:  req.body.empName?"'%"+req.body.empName+"%'":"''"                                  
                                };
                                try {       
                                  const pool = await helper.poolPromise;      //simple query                         
                                        const accountId=req.body.accountId;                      
                                       let result  =  await pool.request().query(`select account_id, account_name, emp_id,ep_name,effective_date,term_date,notes from ctst_cust_empl_acct_dtls where account_name like ${getAccData.accountName} or primary_location_state like ${getAccData.empName}`)
                                        res.status(200)
                                        res.json(result.recordset);
                                      } catch (err) {
                                     res.status(500);          
                                     res.send(err.message)
                                      }      
                                  }

                                  async function addacctdtls(req,res) {    
                                    try {
                                      const pool = await helper.poolPromise;   
                                            //simple query
                                            const account_id = req.body.accountid;
                                            const account_name = req.body.accountname;
                                            const primary_location_city = req.body.city;
                                            const primary_location_state = req.body.state;
                                            const cluster_id = req.body.clusterval;
                                          let result  =  await pool.request().query(`insert into ctst_cust_acct_dtls (account_id,account_name,primary_location_city,primary_location_state,cluster_id) values(${account_id} ,'${account_name}','${primary_location_city}','${primary_location_state}',${cluster_id})`)
                                           res.status(200)
                                           res.send(result.rowsAffected +' Account Details inserted ')
                                          } catch (err) {
                                            res.status(500);          
                                            res.send(err.message)
                                           }
                                      }
                                      async function addemplactdtls(req,res) {    
                                        try {
                                          const pool = await helper.poolPromise;   
                                                //simple query
                                                const employeeId = req.body.empId;
                                                const accountIddtl = req.body.accountid;
                                                const effdt = req.body.effdate;
                                                const termdt = req.body.termdate;
                                                const notesdtls = req.body.notes;
                                              let result  =  await pool.request().query(`insert into ctst_cust_empl_acct_dtls (emp_id,account_id,effective_date,term_date,notes) values(${employeeId} ,${accountIddtl},${effdt},${termdt},'${notesdtls}')`)
                                               res.status(200)
                                               res.send(result.rowsAffected +' Employee Account details inserted ')
                                              } catch (err) {
                                                res.status(500);          
                                                res.send(err.message)
                                           }
                                       }
                
module.exports = {
  getAccountProdDataById,
  getAcctProductByName,
  getAllAccountProdData,
  updateAccount,
  getAccountById,
  getAllAccount,
  getAccountByNameCity,
  getAllEmpAccountDetails,
  addacctdtls,
  addemplactdtls
}