const helper = require('../helper/helper');
const _ = require('lodash');

 async function getEmployee(req,res) {            
    try {       
      const pool = await helper.poolPromise;       
            //simple query
            const employeeId = req.params.id;
           let result  =  await pool.request().query(`select * from ctst_cust_empl_dtls where emp_id =${employeeId}`);
           res.json(result.recordset);
          } catch (err) {
         res.status(500);          
         res.send(err.message)
          }      
      }


      async function updateEmployee(req,res) {            
    try {       
            const pool = await helper.poolPromise;   
            //simple query
            const employeeName = req.body.name;
            const employeeId = req.params.id;
          
            let result  =  await pool.request().query(`update ctst_cust_empl_dtls set emp_name ='${employeeName}' where emp_id=${employeeId}`)            
           res.status(200)
           res.send(result.rowsAffected +' Employee updated ')
           } catch (err) {
            res.status(500);          
            res.send(err.message)
           }     
     
      }

    async function updateEmployeeSkills(req,res) {    
        
    try {       

      const updateSkills = {
        id: req.body.id,
        skillName: req.body.skillName,
        skillType: req.body.skillType,
        skillWeight: req.body.skillWeight,
        updateUser: req.body.user
      };

      const pool = await helper.poolPromise;   
            //simple query
           let result  =  await pool.request().query(`update ctst_cust_skill_dtls set Skill_name ='${updateSkills.skillName}', Skill_type='${updateSkills.skillType}',Skill_weight = '${updateSkills.skillWeight}',update_user = '${updateSkills.updateUser}' where Skill_ID=${updateSkills.id}`)            
           res.status(200)
           res.send(result.rowsAffected +' Skill updated ')
          } catch (err) {
            res.status(500);          
            res.send(err.message)
           }   
      }

      async function getEmpSkillsData(req,res) {            
        try {       
          const getEmpSkillData = {
            employeeName: req.body.employeeName?"'"+req.body.employeeName+"'":"''",
            skillName:  req.body.skillName?"'"+req.body.skillName+"'":"''"
          };
    
          const pool = await helper.poolPromise;   
                //simple query
               let result  =  await pool.request().query(`select emp_name,emp.emp_id from ctst_cust_empl_dtls emp join ctst_cust_empl_skill_dtls emp_skill on emp.emp_id = emp_skill.emp_id join ctst_cust_skill_dtls skill on skill.Skill_ID = emp_skill.skill_id where (emp.emp_name=${getEmpSkillData.employeeName} or skill.skill_name=${getEmpSkillData.skillName})`)               
               res.status(200)
               res.json(result.recordset);
              } catch (err) {
                res.status(500);          
                res.send(err.message)
               }            
          }
          async function addAssociate(req,res) {    
        
            try {       
        
              const pool = await helper.poolPromise;   
                    //simple query
                    const employeeName = req.body.empName;
                    const employeeId = req.body.empId;               
                  let result  =  await pool.request().query(`insert into ctst_cust_empl_dtls (emp_id,emp_name) values(${employeeId} ,'${employeeName}')`)               
                   res.status(200)
                   res.send(result.rowsAffected +' Employee details inserted ')
                  } catch (err) {
                    res.status(500);          
                    res.send(err.message)
                   }   
             
              }

              async function addempSkills(req,res) {    
        
                try {       
            
                  const pool = await helper.poolPromise;   
                        //simple query
                        const empSkillID = req.body.skillId;
                        const employeeId = req.body.empId;
                      let result  =  await pool.request().query(`insert into ctst_cust_empl_skill_dtls(emp_id,skill_id,update_date) values(${employeeId} ,${empSkillID},GETDATE())`)               
                       res.status(200)
                       res.send(result.rowsAffected +' Employee Skill inserted ')
                      } catch (err) {
                        res.status(500);          
                        res.send(err.message)
                       }   
                 
                  }

                  async function addSkilldtls(req,res) {    
        
                    try {       
                
                      const pool = await helper.poolPromise;   
                            //simple query
                            const skillId = req.body.skillId;
                            const sKillName = req.body.skillName;
                            const skillType = req.body.skillType;
                            const skillWeight = req.body.skillWeight;
                            const currentdate = req.currentdate;
                            const currentuser = req.curruser;
                          let result  =  await pool.request().query(`insert into ctst_cust_skill_dtls(skill_id,skill_name,skill_type,skill_weight,update_date,update_user) values(${skillId} ,'${sKillName}','${skillType}',${skillWeight},GETDATE(),SYSTEM_USER)`)
                           res.status(200)
                           res.send(result.rowsAffected +' Skill Details inserted ')
                          } catch (err) {
                            res.status(500);          
                            res.send(err.message)
                           }
                      }



module.exports = {
    getEmployee,
    updateEmployee,
    updateEmployeeSkills,
    getEmpSkillsData,
    addAssociate,
    addempSkills,
    addSkilldtls
}

