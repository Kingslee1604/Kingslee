const helper = require('../helper/helper');
const _ = require('lodash');

async function getInventoryByAccountId(req,res) {            
    try {       
      const pool = await helper.poolPromise;       
            //simple query
            const accountId = req.body.accountId
           let result  =  await pool.request().query(`select account_id, inventory_name, inventory_desc, mapping, functional_category, type, source, destination, frequency from ctst_cust_acct_invet_dtls where account_id =${accountId}`);
           res.json(result.recordset);
          } catch (err) {
         res.status(500);          
         res.send(err.message)
          }      
      }



      async function getInventory(req,res) {            
        try {       
          const pool = await helper.poolPromise;       
                //simple query
                const inventoryDetails = {
                 inventoryName :  req.body.inventoryName?"'%"+req.body.inventoryName+"%'":"''",
                 inventoryDesc :  req.body.inventoryDesc?"'%"+req.body.inventoryDesc+"%'":"''",
                 mapping :  req.body.mapping?"'%"+req.body.mapping+"%'":"''",
                 funcCategory :  req.body.funcCategory?"'%"+req.body.funcCategory+"%'":"''",
                 destination :  req.body.destination?"'%"+req.body.destination+"%'":"''",
                 frequency :  req.body.frequency?"'%"+req.body.frequency+"%'":"''"
                }
               let result  =  await pool.request().query(`select account_id, inventory_name, inventory_desc, mapping, functional_category, type, source, destination, frequency from ctst_cust_acct_invet_dtls ` +
               `where inventory_name like ${inventoryDetails.inventoryName} or inventory_desc like ${inventoryDetails.inventoryDesc} or mapping like ${inventoryDetails.mapping} or `+
               `functional_category like ${inventoryDetails.funcCategory} or destination like ${inventoryDetails.destination} or frequency like ${inventoryDetails.frequency}`);
               res.json(result.recordset);
              } catch (err) {
             res.status(500);          
             res.send(err.message)
              }      
          }


          
      async function updateInventory(req,res) {            
        try {       
          const pool = await helper.poolPromise;       
                //simple query
                const inventoryDetails = {
                 inventoryName :  req.body.inventoryName,
                 inventoryDesc :  req.body.inventoryDesc,
                 mapping :  req.body.mapping,
                 funcCategory :  req.body.funcCategory,
                 destination :  req.body.destination,
                 frequency :  req.body.frequency,
                 accountName:req.body.accountName?"'%"+req.body.accountName+"%'":"''",
                 updateUser : req.body.updateUser
                }
               let result  =  await pool.request().query(`update ctst_cust_acct_invet_dtls ` +
               `set inventory_name = '${inventoryDetails.inventoryName}', inventory_desc = '${inventoryDetails.inventoryDesc}', mapping =  '${inventoryDetails.mapping}' , `+
               `functional_category = '${inventoryDetails.funcCategory}' , destination = '${inventoryDetails.destination}' , frequency = '${inventoryDetails.frequency}', update_date = getdate() , update_user =${inventoryDetails.updateUser} where ` +
               `account_id= (select account_id from ctst_cust_acct_dtls where account_name like ${inventoryDetails.accountName})`);
               res.status(200)
               res.send(result.rowsAffected +' Inventory updated ')
              } catch (err) {
             res.status(500);          
             res.send(err.message)
              }      
          }
          async function addacctinvtdtls(req,res) {    
            try {
              const pool = await helper.poolPromise;   
                    //simple query
                    const account_id = req.body.accountid;
                    const inventory_name = req.body.invtname;
                    const inventory_desc = req.body.invtdesc;
                    const mapping = req.body.mapping;
                    const functional_category = req.body.funccategory;
                    const type = req.body.type;
                    const Source = req.body.Source;
                    const Destination = req.body.Destination;
                    const Frequency = req.body.Frequency;
                  let result  =  await pool.request().query(`insert into ctst_cust_acct_invet_dtls (account_id,inventory_name,inventory_desc,mapping,functional_category,type,Source,Destination,Frequency,update_date,update_user) values(${account_id} ,'${inventory_name}','${inventory_desc}','${mapping}','${functional_category}','${type}','${Source}','${Destination}','${Frequency}',GETDATE(),SYSTEM_USER)`)
                   res.status(200)
                   res.send(result.rowsAffected +' Account and its Product Details inserted ')
                  } catch (err) {
                    res.status(500);          
                    res.send(err.message)
                   }
              }

module.exports = {
    getInventoryByAccountId,
    getInventory,
    updateInventory,
    addacctinvtdtls
}