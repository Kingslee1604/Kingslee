const helper = require('../helper/helper');
const _ = require('lodash');

 async function getProduct(req,res) {            
    try {       
      const pool = await helper.poolPromise;       
            //simple query
            const prodName = req.body.prodName;
           let result  =  await pool.request().query(`select * from ctst_cust_product_dtls where product_name ='${prodName}'`);
           res.json(result.recordset);
          } catch (err) {
         res.status(500);          
         res.send(err.message)
          }      
      }


      async function getProductDesc(req,res) {            
        try {       
          const pool = await helper.poolPromise;       
                //simple query
                const prodNameDesc = req.body.prodNameDesc;
               let result  =  await pool.request().query(`select * from ctst_cust_product_dtls where product_desc like'%${prodNameDesc}%'`);
               res.json(result.recordset);
              } catch (err) {
             res.status(500);          
             res.send(err.message)
              }      
          }
    
          async function getProdOnVendor(req,res) {            
            try {       
              const pool = await helper.poolPromise;       
                    //simple query
                    const vendorName = req.body.vendorName;
                   let result  =  await pool.request().query(`select * from ctst_cust_product_dtls where vendor like'%${vendorName}%'`);
                   res.json(result.recordset);
                  } catch (err) {
                 res.status(500);          
                 res.send(err.message)
                  }      
              }
                                   
 
              async function updateVendor(req,res) {            
                try {       
                  const pool = await helper.poolPromise;       
                        //simple query
                        const productId = req.body.productId;
                        const productName = req.body.prodName;
                        const isTrizetto = req.body.isTrizetto;
                        const vendorName = req.body.vendorName;
                        const prodDesc = req.body.prodDesc;                        
                       let result  =  await pool.request().query(`update ctst_cust_product_dtls set product_name ='${productName}' , is_Trizetto = '${isTrizetto}', vendor = '${vendorName}', product_desc = '${prodDesc}', update_date = getdate() where product_id = ${productId}`);
                       res.status(200)
                       res.send(result.rowsAffected +' Product updated ')
                      } catch (err) {
                     res.status(500);          
                     res.send(err.message)
                      }      
                  }     
                  async function addpdpddtls(req,res) {    
                    try {
                      const pool = await helper.poolPromise;   
                            //simple query
                            const product_id = req.body.productid;
                            const product_name = req.body.productname;
                            const is_Trizetto = req.body.isTrizetto;
                            const vendordtls = req.body.vendor;
                            const product_desc = req.body.pdpddesc;
                          let result  =  await pool.request().query(`insert into ctst_cust_product_dtls(product_id,product_name,is_Trizetto,vendor,product_desc,update_date,update_user)values(${product_id} ,'${product_name}','${is_Trizetto}','${vendordtls}','${product_desc}',GETDATE(),SYSTEM_USER)`)
                           res.status(200)
                           res.send(result.rowsAffected +' Product Details inserted ')
                          } catch (err) {
                            res.status(500);          
                            res.send(err.message)
                           }
                      }

                      async function addacctpdpddtls(req,res) {    
                        try {
                          const pool = await helper.poolPromise;   
                                //simple query
                                const account_id = req.body.accountid;
                                const product_id = req.body.productid;
                                const effective_date = req.body.effdate;
                                const term_date = req.body.termdate;
                                const version = req.body.versiondtls;
                              let result  =  await pool.request().query(`insert into ctst_cust_acct_product_dtls (account_id,product_id,effective_date,term_date,version,update_date) values(${account_id} ,${product_id},${effective_date},${term_date},${version},GETDATE())`)
                               res.status(200)
                               res.send(result.rowsAffected +' Account and its Product Details inserted ')
                              } catch (err) {
                                res.status(500);          
                                res.send(err.message)
                               }
                          }

                          async function deletepdpddtls(req,res) {    
                            try {
                              const pool = await helper.poolPromise;   
                                    //simple query
                                    const product_id = req.body.productid;
                                  let result  =  await pool.request().query(`delete from ctst_cust_product_dtls where product_id in (${product_id} )`)
                                   res.status(200)
                                   res.send(result.rowsAffected +' Product Details Deleted ')
                                  } catch (err) {
                                    res.status(500);          
                                    res.send(err.message)
                                   }
                              }
                              async function addprojdtls(req,res) {    
                                try {
                                  const pool = await helper.poolPromise;   
                                        //simple query
                                        const account_id = req.body.accountid;
                                        const project_id = req.body.projectid;
                                        const project_name = req.body.projname;
                                        const effective_date = req.body.effdate;
                                        const term_date = req.body.termdate;
                                        const notesdtls = req.body.notes;
                                        const next_milestone = req.body.nextmilestone;
                                        const project_type = req.body.projtype;
                                      let result  =  await pool.request().query(`insert into ctst_cust_projt_dtls (account_id,project_id,project_name,effective_date,term_date,notes,next_milestone,project_type,update_date,update_user) values(${account_id} ,${project_id},'${project_name}',${effective_date},${term_date},'${notesdtls}','${next_milestone}','${project_type}',GETDATE(),SYSTEM_USER)`)
                                       res.status(200)
                                       res.send(result.rowsAffected +' Project Details inserted ')
                                      } catch (err) {
                                        res.status(500);          
                                        res.send(err.message)
                                       }
                                  }
                                      
      module.exports = {
        getProduct,
        getProductDesc,
        getProdOnVendor,
        updateVendor,
        addpdpddtls,
        addacctpdpddtls,
        deletepdpddtls,
        addprojdtls
    }
    