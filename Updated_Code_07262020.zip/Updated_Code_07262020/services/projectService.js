const helper = require('../helper/helper');
const _ = require('lodash');

async function getProject(req,res) {            
    try {       
      const pool = await helper.poolPromise;       
            //simple query
            const project_name = req.body.projName;
           let result  =  await pool.request().query(`select * from ctst_cust_projt_dtls where project_name ='${project_name}'`);
           res.json(result.recordset);
          } catch (err) {
         res.status(500);          
         res.send(err.message)
          }      
      }

async function addprojdtlstest(req,res) {    
    try {
      const pool = await helper.poolPromise;   
            //simple query
            const account_id = req.body.accountid;
            const project_id = req.body.projectid;
            const project_name = req.body.projname;
            const effective_date = req.body.effdate;
            const term_date = req.body.termdate;
            const notesdtls = req.body.notes;
            const next_milestone = req.body.nextmilestone;
            const project_type = req.body.projtype;
          let result  =  await pool.request().query(`insert into ctst_cust_projt_dtls (account_id,project_id,project_name,effective_date,term_date,notes,next_milestone,project_type,update_date,update_user) values(${account_id} ,${project_id},'${project_name}',${effective_date},${term_date},'${notesdtls}','${next_milestone}','${project_type}',GETDATE(),SYSTEM_USER)`)
           res.status(200)
           res.send(result.rowsAffected +' Project Details inserted ')
          } catch (err) {
            res.status(500);          
            res.send(err.message)
           }
      }
          
module.exports = {
    addprojdtlstest,
    getProject
}
