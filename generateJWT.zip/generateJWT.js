const jwt = require('jsonwebtoken');
var generateJWT = function(keyInfo) {
 
    var payLoad = {
        role:'Cognizant-Associate-Profiling',
        iss:'Cognizant',
        aud:'Cognizant.com',
        winaccountname:'associate_profiling',
        OrgType :'wsNotSet',
        nbf: Math.floor(Date.now() /1000),
        exp: Math.floor(Date.now()/1000)+(60*3000)
    }
    return jwt.sign(payLoad,"asdfjehred@!'09333");
}

console.log(generateJWT());

//eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiQ29nbml6YW50LUFzc29jaWF0ZS1Qcm9maWxpbmciLCJpc3MiOiJDb2duaXphbnQiLCJhdWQiOiJDb2duaXphbnQuY29tIiwid2luYWNjb3VudG5hbWUiOiJhc3NvY2lhdGVfcHJvZmlsaW5nIiwiT3JnVHlwZSI6IndzTm90U2V0IiwibmJmIjoxNTkxODM2NDU0LCJleHAiOjE1OTIwMTY0NTQsImlhdCI6MTU5MTgzNjQ1NH0.lFLKki9CKJXeM0os-qzI19QgNhl8lNapaSkuHnOelIU