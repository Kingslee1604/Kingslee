const sql = require('mssql/msnodesqlv8');

const pool = new sql.ConnectionPool({
  database: 'asociate_Profiling',
  server: 'localhost',
  driver: 'msnodesqlv8',
  options: {
    trustedConnection: true
  }
})
console.log('dsfdsfds');
pool.connect().then(() => {
    console.log('connected');
  //simple query
  pool.request().query('select * from emp', (err, result) => {
        console.log(result)
    })
})